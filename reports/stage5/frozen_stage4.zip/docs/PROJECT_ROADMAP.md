# Project roadmap

Stage 1 provides the local foundation. Stage 2 adds automatic construction from local fictional documents. Stage 3 adds local MiniLM embeddings, real Neo4j vector indexing, vector-only retrieval, and a deterministic text answerer. Stage 4 implements bounded graph-only multi-hop retrieval, canonical linking, strict source proof, and a measured comparison on the same 122 synthetic questions.

The next stages require a separate request and design review. They are not started automatically.

| Proposed stage | Main work | Evidence needed before claiming success |
| --- | --- | --- |
| 2: ingestion and entity resolution (implemented) | Versioned sources, controlled grammar, reviewed aliases, gated publication, local CLI | See Stage 2 report for actual checks, precision/recall, and limitations |
| 3: vector baseline (implemented) | Local MiniLM, versioned Neo4j cosine index, text-only answers and API | See Stage 3 report and reports/stage3 for real checks, quality, performance, and limitations |
| 4: graph-only retrieval (implemented) | Bounded one-/two-/three-hop traversal, canonical identity, provenance, deterministic path answers | See Stage 4 report: working original-domain paths, zero benchmark answerable accuracy due to frozen upstream coverage, safe abstention, measured latency |
| 5: answer generation | Citation-bound answers, optional model provider, refusal when evidence is missing | Groundedness checks, citation resolution, unanswerable-case behavior |
| 6: measured comparison | Compare graph/hybrid retrieval with the vector baseline under the same conditions | Answer accuracy, evidence recall, latency, resource cost, repeatable settings |

The Neo4j GraphRAG Python package can be introduced when it removes useful implementation work. Optional LangGraph or a real LLM provider needs a concrete use case. Paid APIs, deployments, GitHub publication, commits, and pushes are outside the authorized work. Stage 5 has not started. Hybrid retrieval and expanding the reviewed extraction registry require a separate authorized change; neither is hidden inside graph-only mode.

No benchmark improvement is claimed. Graph-only accuracy is 0% at all three hop counts on the frozen dataset, while vector-only retains 97.22%/25.00%/4.17%. The next coverage problem is explicit: the benchmark introduces identities absent from the reviewed registry and accepted graph facts. Stage 4 did not change that snapshot to improve its scores. See [Stage 4 evaluation](GRAPH_EVALUATION.md).
