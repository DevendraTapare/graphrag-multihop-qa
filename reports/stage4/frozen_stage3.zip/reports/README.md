# Verification evidence

Stage 3 evidence is in `stage3/`:

- `baseline_metrics.json` and `.csv`: real MiniLM/Neo4j results by k, hop, split, and individual question.
- `error_analysis.md`: missing evidence and generation failures at k=5.
- `performance.json`: controlled warm batch indexing, repeated indexing, and concurrency measurements.
- `runtime_verification.json`: actual HTTP startup, vector requests, Compose outage, and recovery.
- `test_results.json`: complete regression/integration test statuses and counts.
- `index_verification.json`: actual index schema, dimensions, source count, idempotency, and Stage 1–2 preservation.
- `FILE_MANIFEST.md`: Stage 3 additions and changed existing files.
- `../docs/STAGE3_REPORT.md`: measured outcome and limitations.

Stage 2 evidence:

- `stage2-test-results.json`: final full regression suite, including real Neo4j cases.
- `stage2-corpus-verification.json`: 16-document import, repeated-load equality, source audits, and Stage 1 preservation.
- `extraction-evaluation.json`: calibration, held-out, combined, and per-case synthetic extraction measurements.
- `stage2-runtime-verification.json`: real database outage/recovery and ingestion results.
- `stage2-cli-verification.json`: successful summary, validation, rejection/conflict inspection, and history listing.
- `STAGE2_FILE_MANIFEST.md`: current shareable inventory and changed Stage 1 files.
- `../docs/STAGE2_REPORT.md`: complete Stage 2 report and limitations.

Historical Stage 1 evidence:

- `test-results.json`: all 78 cases from the final successful JUnit report, including 18 real Neo4j integration cases. No cases were skipped.
- `graph-validation.json`: live graph counts and the verified Priya evidence paths.
- `runtime-verification.json`: real process startup and database outage/recovery HTTP results.
- `FILE_MANIFEST.md`: shareable project files created in Stage 1.
- `../docs/STAGE1_REPORT.md`: the complete report and limitations.

Ignored local artifacts include `.log` files, JUnit `.xml` files, and `runtime-api-process.json`. The latter records the PID of the local review API started during implementation. To stop that process in the same Windows session:

```powershell
$reviewApi = Get-Content reports/runtime-api-process.json | ConvertFrom-Json
Get-CimInstance Win32_Process -Filter "ProcessId = $($reviewApi.pid)" |
    Where-Object { $_.CommandLine -like '*-m scripts.serve*' } |
    ForEach-Object { Stop-Process -Id $_.ProcessId }
```

The command checks the process command line before stopping it because Windows can reuse process IDs. Neo4j can be stopped separately with `docker compose stop neo4j`. To run the API again in the foreground, use `uv run python -m scripts.serve` and stop it with Ctrl+C.
