# Project roadmap

Stage 1 provides the local foundation. Stage 2 adds automatic construction from local fictional documents. Stage 3 adds local MiniLM embeddings, real Neo4j vector indexing, vector-only retrieval, a deterministic text answerer, and separate retrieval/generation measurements on 122 synthetic questions.

The next stages require a separate request and design review. They are not started automatically.

| Proposed stage | Main work | Evidence needed before claiming success |
| --- | --- | --- |
| 2: ingestion and entity resolution (implemented) | Versioned sources, controlled grammar, reviewed aliases, gated publication, local CLI | See Stage 2 report for actual checks, precision/recall, and limitations |
| 3: vector baseline (implemented) | Local MiniLM, versioned Neo4j cosine index, text-only answers and API | See Stage 3 report and reports/stage3 for real checks, quality, performance, and limitations |
| 4: graph and hybrid retrieval | Bounded multi-hop traversal, candidate disambiguation, evidence selection | Path correctness, source coverage, latency, failures and abstentions |
| 5: answer generation | Citation-bound answers, optional model provider, refusal when evidence is missing | Groundedness checks, citation resolution, unanswerable-case behavior |
| 6: measured comparison | Compare graph/hybrid retrieval with the vector baseline under the same conditions | Answer accuracy, evidence recall, latency, resource cost, repeatable settings |

The Neo4j GraphRAG Python package can be introduced when it removes useful implementation work. Optional LangGraph or a real LLM provider needs a concrete use case. Paid APIs, deployments, GitHub publication, commits, and pushes are outside the authorized work. Stage 4 has not started.

No benchmark improvement is claimed. This small corpus demonstrates an evidence chain, not a production-scale retrieval advantage.
